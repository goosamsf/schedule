CalPoly CSC453 : Introduction to Operating System

Instructor : Irene Humer
Student : Youngjun Park

Implementing Round-Robin scheduling 

NOTE :
	After compilation using Makefile(when there is a executable named "schedule"), 
	it is recommended to run through provided shell-script "run.sh" 
	e.g) ./run.sh 1000 ls : two 1 : two 2 : two 3
	e.g) ./run.sh <list of arguments>
	It is simple shell script that if the program name exists in current directory, it just append `./` in front of program name so that the main program doesn't have to deal with string manipulation or the grader doesn't have to deal with PATH variable.

